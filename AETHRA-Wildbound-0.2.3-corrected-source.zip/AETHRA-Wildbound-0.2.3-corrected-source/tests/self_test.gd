extends SceneTree

func _init() -> void:
    var checks := []
    checks.append(_check("Block registry", func(): return BlockRegistry.get_block(BlockRegistry.STONE).name == "Stone"))
    checks.append(_check("Item registry", func(): return ItemRegistry.get_item(ItemRegistry.IRON_PICK).durability > 0))
    checks.append(_check("Recipes", func(): return not RecipeRegistry.find_recipe("wood_pick").is_empty()))
    var generator = load("res://scripts/world/world_generator.gd").new(1234)
    checks.append(_check("Deterministic terrain", func(): return generator.block_at(14, 32, -9) == generator.block_at(14, 32, -9)))
    var inv = load("res://scripts/gameplay/inventory.gd").new()
    inv.add_item(BlockRegistry.LOG, 4)
    checks.append(_check("Inventory", func(): return inv.count_item(BlockRegistry.LOG) == 4))
    var survival = load("res://scripts/gameplay/survival.gd").new()
    survival.apply_damage(3)
    checks.append(_check("Survival damage", func(): return survival.health == 17.0))
    for result in checks:
        print("[TEST] %s: %s" % [result[0], "PASS" if result[1] else "FAIL"])
    if checks.any(func(x): return not x[1]):
        quit(1)
    quit(0)

func _check(name: String, fn: Callable) -> Array:
    return [name, bool(fn.call())]
