extends RefCounted

const CHUNK_SIZE := 16
const WORLD_HEIGHT := 96
const SEA_LEVEL := 34
const VERSION := 1

var seed_value: int
var continental := FastNoiseLite.new()
var detail := FastNoiseLite.new()
var caves := FastNoiseLite.new()
var ore := FastNoiseLite.new()
var structures_enabled := true

func _init(world_seed: int) -> void:
    seed_value = world_seed
    continental.seed = seed_value
    continental.frequency = 0.0025
    continental.fractal_octaves = 5
    detail.seed = seed_value ^ 0x4A11C0DE
    detail.frequency = 0.016
    detail.fractal_octaves = 3
    caves.seed = seed_value ^ 0x11C4BEEF
    caves.frequency = 0.028
    caves.fractal_octaves = 2
    ore.seed = seed_value ^ 0x7788AA11
    ore.frequency = 0.07

func configure(enable_structures: bool = true) -> void:
    structures_enabled = enable_structures

func terrain_height(x: int, z: int) -> int:
    var macro := continental.get_noise_2d(x, z)
    var detail_v := detail.get_noise_2d(x, z)
    var h := SEA_LEVEL + int(macro * 22.0 + detail_v * 7.0)
    return clampi(h, 4, WORLD_HEIGHT - 8)

func biome_at(x: int, z: int) -> String:
    var temp := continental.get_noise_2d(x + 10000, z + 10000)
    var moisture := continental.get_noise_2d(x - 16000, z - 16000)
    if temp > 0.45 and moisture < -0.1:
        return "arid"
    if temp < -0.45:
        return "frost"
    if moisture > 0.35:
        return "grove"
    return "meadow"

func block_at(x: int, y: int, z: int) -> int:
    if y < 0:
        return BlockRegistry.BEDROCK
    if y >= WORLD_HEIGHT:
        return BlockRegistry.AIR
    if y == 0:
        return BlockRegistry.BEDROCK
    var surface := terrain_height(x, z)
    if _is_cave(x, y, z) and y > 4 and y < surface - 3:
        return BlockRegistry.AIR
    if y > surface:
        if y <= SEA_LEVEL:
            return BlockRegistry.WATER
        return _tree_block(x, y, z, surface) if structures_enabled else BlockRegistry.AIR
    var biome := biome_at(x, z)
    if y == surface:
        if surface <= SEA_LEVEL + 1:
            return BlockRegistry.SAND
        if biome == "frost":
            return BlockRegistry.SNOW
        if biome == "arid":
            return BlockRegistry.SAND
        return BlockRegistry.SOIL
    if y >= surface - 3:
        return BlockRegistry.SAND if biome == "arid" else BlockRegistry.SOIL
    return _subsurface_resource(x, y, z)

func generate_chunk(cx: int, cz: int) -> PackedByteArray:
    var data := PackedByteArray()
    data.resize(CHUNK_SIZE * CHUNK_SIZE * WORLD_HEIGHT)
    var i := 0
    for lx in CHUNK_SIZE:
        for lz in CHUNK_SIZE:
            for y in WORLD_HEIGHT:
                data[i] = block_at(cx * CHUNK_SIZE + lx, y, cz * CHUNK_SIZE + lz)
                i += 1
    return data

func _is_cave(x: int, y: int, z: int) -> bool:
    var n := caves.get_noise_3d(x, y * 1.08, z)
    var vertical := absf(float(y - 42) / 40.0)
    return n > 0.58 and vertical < 0.9

func _subsurface_resource(x: int, y: int, z: int) -> int:
    var n := ore.get_noise_3d(x, y, z)
    if y < 40 and y > 8 and n > 0.71:
        return BlockRegistry.COPPER_ORE
    if y < 30 and y > 5 and n > 0.79:
        return BlockRegistry.IRON_ORE
    if y < 18 and n > 0.88:
        return BlockRegistry.CRYSTAL_ORE
    return BlockRegistry.STONE

func _tree_block(x: int, y: int, z: int, surface: int) -> int:
    var trunk_key := posmod(hash(Vector3i(x, surface, z)), 97)
    if trunk_key != 0 and trunk_key > 4:
        return BlockRegistry.AIR
    var top := surface + 4 + posmod(x * 13 + z * 7, 3)
    if y > surface and y <= top and x % 2 == 0 and z % 2 == 0:
        return BlockRegistry.LOG
    if y >= top - 2 and y <= top + 1:
        return BlockRegistry.LEAVES
    return BlockRegistry.AIR
