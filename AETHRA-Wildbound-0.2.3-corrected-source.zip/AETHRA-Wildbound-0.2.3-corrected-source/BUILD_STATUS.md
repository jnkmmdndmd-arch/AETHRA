# AETHRA: Wildbound — Build Status

## Implemented in source
- Native Godot client hub rebuilt with functional sidebar, search, profile, hero, quick actions, recent worlds, social panel, server favorites, discovery fallback, settings, developer metrics, notifications empty-state, and window controls.
- Real data bindings for SaveDB, AppState, NetworkManager, ServerDirectory, Engine/Performance, Settings, and AudioManager.
- World resume, rename, duplicate, backup, delete flows are connected to SaveDB.
- Remote join waits for authoritative world metadata instead of inventing a seed on connection.
- Dedicated-server export points to `server/main_server.tscn`.
- Original generated hero artwork is stored locally under `assets/ui/hero_background.png`.

## Not claimed as PASS in this environment
- Godot editor import/runtime UI test: blocked because Godot 4.7.2 is not installed in the execution environment.
- Windows release export: blocked by missing Godot export templates/runtime.
- Android/iOS export: blocked by missing platform export toolchains.
- Global server discovery: no discovery service exists in this foundation, so the client uses real saved favorites/direct connection only.
- Store commerce: unavailable until a real payment/backend service is integrated.

## Rule
Only source-level/static validation has been performed here; runtime PASS is not claimed for features that require the Godot editor, Windows, Android, iOS, or a live dedicated server.

## Release hardening (current)
- Windows export preset targets x86_64 with embedded project resources (`binary_format/embed_pck=true`).
- `build_windows.ps1` verifies Godot 4.7.2, cleans stale build files, exports Release, and enforces a one-file `AETHRA-Wildbound.exe` release directory.
- Windows CI is configured with the official Godot setup action and export templates and can be started manually with `workflow_dispatch`.
- `build_windows.ps1 -CopyToDesktop` copies the verified EXE to the Windows user's Desktop after export.
- The current execution environment is Linux and has no Godot 4.7.2 exporter installed, so Windows runtime remains BLOCKED BY ENVIRONMENT here.
