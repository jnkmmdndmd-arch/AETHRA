# AETHRA: Wildbound — 0.2.3 corrected-final-source

Status: SOURCE RELEASE CANDIDATE — NOT A VERIFIED WINDOWS RUNTIME RELEASE

Verified in this environment: source-level asset/resource checks and Go auth service tests where applicable.
Not verified here: Godot import/runtime, Windows EXE runtime, Windows single-EXE launch, internet multiplayer runtime, Android/iOS runtime.

Architecture-dependent features intentionally remain PARTIAL when their required backend/infrastructure is not present: social friends, global server discovery, notifications, per-world thumbnail capture, full anti-cheat, and production TLS deployment.
